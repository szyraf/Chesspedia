﻿<?php

$tekst_01 = <<<TEKST_01
Some text in english ...
TEKST_01;



$tekst_02 = <<<TEKST_02
Other text in english ...
TEKST_02;



?>