﻿<?php

$title = <<<TITLE
Szachy
TITLE;

$tekst_01 = <<<TEKST_01
Tutaj jakiś tekst po polsku..
TEKST_01;


$tekst_02 = <<<TEKST_02
inny tekst po polsku ...
TEKST_02;


?>